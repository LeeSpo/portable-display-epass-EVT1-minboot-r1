EVT1 V851s 3-ring fanout baseline
Via 0.40/0.20, HD 0.09/0.09
54/54 non-display fanout
73 hole_clearance errors vs 0.250 mm hole-to-copper
saved 2026-09-04T18:11:17Z
