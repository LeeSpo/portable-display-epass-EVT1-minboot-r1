#!/usr/bin/env python3
"""Generate the self-contained KiCad EVT1 design and manufacturing metadata.

The design is intentionally data driven: symbol pin numbers, PCB pad numbers and
the BOM are emitted from the same Device records so that the three views cannot
silently drift apart.  KiCad itself remains the authority for ERC/DRC and plots.
"""

from __future__ import annotations

import csv
import heapq
import json
import math
import os
import shutil
import uuid
from dataclasses import dataclass, field
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "manufacturing" / "evt1"
LIB = ROOT / "sameat.pretty"
NS = uuid.UUID("2b818650-a5d9-4e5d-af21-2d46ab184ac6")
DISPLAY_NETS = {
    "DSI_D0N", "DSI_D0P", "DSI_D1N", "DSI_D1P", "DSI_CKN", "DSI_CKP",
    "LCD_RST", "LCD_PWM", "LCD_EN", "LCD_3V3", "LEDA", "LEDK", "BL_SW",
}
PLANE_NETS = {"GND", "3V3", "CORE_0V93", "1V8", "DRAM_1V5", "RTC_3V3", "VSYS", "VBAT", "VBUS", "SD_3V3"}
VIA_SIZE = 0.40
VIA_DRILL = 0.20
HD_WIDTH = 0.09
HD_CLEAR = 0.09
NORM_WIDTH = 0.15
USB_WIDTH = 0.15
USB_GAP = 0.15
V851_RINGS = (1.15, 1.90, 2.65)


def uid(name: str) -> str:
    return str(uuid.uuid5(NS, name))


def q(value: object) -> str:
    return '"' + str(value).replace("\\", "\\\\").replace('"', '\\"') + '"'


@dataclass
class Pad:
    number: str
    x: float
    y: float
    sx: float
    sy: float
    shape: str = "roundrect"
    angle: float = 0.0
    kind: str = "smd"
    layers: tuple[str, ...] = ("F.Cu", "F.Paste", "F.Mask")
    drill: float | None = None


@dataclass
class Device:
    ref: str
    value: str
    footprint: str
    sheet: str
    x: float
    y: float
    pins: dict[str, tuple[str, str | None]]
    mpn: str = ""
    lcsc: str = ""
    datasheet: str = ""
    rotation: float = 0.0
    dnp: bool = False
    note: str = ""
    pads: list[Pad] = field(default_factory=list)


def two_pad(pitch: float = 1.0, size: tuple[float, float] = (0.6, 0.7)) -> list[Pad]:
    return [
        Pad("1", -pitch / 2, 0, *size),
        Pad("2", pitch / 2, 0, *size),
    ]


def row_pads(count: int, pitch: float, sy: float = 1.2) -> list[Pad]:
    start = -(count - 1) * pitch / 2
    return [Pad(str(i + 1), start + i * pitch, 0, min(0.32, pitch * 0.62), sy, "rect") for i in range(count)]


def dual_pads(count: int, body_x: float, pitch: float, pad_size=(1.0, 0.32)) -> list[Pad]:
    assert count % 2 == 0
    side = count // 2
    ys = [-(side - 1) * pitch / 2 + i * pitch for i in range(side)]
    pads: list[Pad] = []
    for i, yy in enumerate(ys):
        pads.append(Pad(str(i + 1), -body_x / 2, yy, *pad_size))
    for i, yy in enumerate(reversed(ys)):
        pads.append(Pad(str(side + i + 1), body_x / 2, yy, *pad_size))
    return pads


def qfn_pads(count: int, body: float, pitch: float, ep_number: str, ep: float) -> list[Pad]:
    assert count % 4 == 0
    side = count // 4
    span = (side - 1) * pitch
    edge = body / 2 + 0.25
    pads: list[Pad] = []
    for i in range(side):
        pads.append(Pad(str(i + 1), -edge, -span / 2 + i * pitch, 0.70, 0.18))
    for i in range(side):
        pads.append(Pad(str(side + i + 1), -span / 2 + i * pitch, edge, 0.18, 0.70))
    for i in range(side):
        pads.append(Pad(str(2 * side + i + 1), edge, span / 2 - i * pitch, 0.70, 0.18))
    for i in range(side):
        pads.append(Pad(str(3 * side + i + 1), span / 2 - i * pitch, -edge, 0.18, 0.70))
    pads.append(Pad(ep_number, 0, 0, ep, ep, "rect"))
    return pads


def lga12_pads() -> list[Pad]:
    # LIS2DW12 2.0 x 2.0 mm LGA-12: three pads per side, 0.5 mm pitch.
    side, pitch, body = 3, 0.5, 2.0
    span = (side - 1) * pitch
    edge = body / 2 + 0.15
    pads: list[Pad] = []
    for i in range(side):
        pads.append(Pad(str(i + 1), -edge, -span / 2 + i * pitch, 0.40, 0.22))
    for i in range(side):
        pads.append(Pad(str(side + i + 1), -span / 2 + i * pitch, edge, 0.22, 0.40))
    for i in range(side):
        pads.append(Pad(str(2 * side + i + 1), edge, span / 2 - i * pitch, 0.40, 0.22))
    for i in range(side):
        pads.append(Pad(str(3 * side + i + 1), span / 2 - i * pitch, -edge, 0.22, 0.40))
    return pads


def usb4105_pads() -> list[Pad]:
    loc = {
        "A1": (-3.2, -3.68, .6), "A4": (-2.4, -3.68, .6), "A5": (-1.25, -3.68, .3),
        "A6": (-.25, -3.68, .3), "A7": (.25, -3.68, .3), "A8": (1.25, -3.68, .3),
        "A9": (2.4, -3.68, .6), "A12": (3.2, -3.68, .6),
        "B1": (3.2, -3.68, .6), "B4": (2.4, -3.68, .6), "B5": (1.75, -3.68, .3),
        "B6": (.75, -3.68, .3), "B7": (-.75, -3.68, .3), "B8": (-1.75, -3.68, .3),
        "B9": (-2.4, -3.68, .6), "B12": (-3.2, -3.68, .6),
    }
    pads = [Pad(n, x, y, sx, 1.15) for n, (x, y, sx) in loc.items()]
    for i, (x, y, sy) in enumerate([(-4.32, -3.105, 2.1), (-4.32, 1.075, 1.8), (4.32, -3.105, 2.1), (4.32, 1.075, 1.8)], 1):
        pads.append(Pad(f"SH{i}", x, y, 1.0, sy, "oval", kind="thru_hole", layers=("*.Cu", "*.Mask"), drill=.6))
    return pads


def microsd_pads() -> list[Pad]:
    # MUP-M617-2 contact row; shell/CD geometry follows the vendor-recommended land pattern.
    pads = [Pad(str(i + 1), -3.5 + i, -4.35, .55, 1.4, "rect") for i in range(8)]
    pads += [Pad("9", 5.1, -1.8, .7, 1.2), Pad("10", -6.0, 1.8, 1.3, 1.8), Pad("11", 6.0, 1.8, 1.3, 1.8)]
    pads += [Pad("12", -5.6, -3.8, 1.2, 1.5), Pad("13", 5.6, -3.8, 1.2, 1.5)]
    return pads


def side_switch_pads() -> list[Pad]:
    return [Pad("1", -2.2, -1.25, 1.1, 1.1), Pad("2", -2.2, 1.25, 1.1, 1.1), Pad("3", 2.2, 0, 1.2, 1.4)]


def crystal4_pads() -> list[Pad]:
    return [Pad("1", -1.2, -.9, 1.0, .9), Pad("2", 1.2, -.9, 1.0, .9), Pad("3", 1.2, .9, 1.0, .9), Pad("4", -1.2, .9, 1.0, .9)]


def battery3_pads() -> list[Pad]:
    return [Pad(str(i + 1), -2 + 2 * i, 0, 1.2, 2.2) for i in range(3)]


def test_header_pads(count: int) -> list[Pad]:
    start = -(count - 1) * 1.27 / 2
    return [Pad(str(i + 1), start + i * 1.27, 0, 1.0, 1.0, "circle", kind="thru_hole", layers=("*.Cu", "*.Mask"), drill=.55) for i in range(count)]


def v851_pins() -> dict[str, tuple[str, str | None]]:
    names = {
        1:"PD18",2:"PD19",3:"PD20",4:"PD21",5:"VCC33_PF_PD",6:"PF0_SDC0_D1",7:"PF1_SDC0_D0",
        8:"PF2_SDC0_CLK",9:"PF3_SDC0_CMD",10:"PF4_SDC0_D3",11:"PF5_SDC0_D2",12:"PF6_DBG_CLK",
        13:"VDD_SYS0",14:"VCC_LDOA_PLL",15:"DXOUT",16:"DXIN",17:"VDD_SYS1",18:"PE13",19:"PE12",
        20:"PE11",21:"PE4",22:"VCC_PE",23:"PE2",24:"PE7",25:"PE0",26:"PE5",27:"PE8",28:"PE9",
        29:"PE3",30:"PE6",31:"PE1",32:"PE10",33:"VDD_SYS2",34:"VCC_DRAM0",35:"VDD_SYS3",
        36:"VCC_DRAM1",37:"VDD18_DRAM",38:"PH14",39:"PH13",40:"PH12",41:"PH11",42:"PH10",
        43:"PH9",44:"VCC_IO",45:"PH0",46:"GPADC0",47:"VDD33",48:"AVCC",49:"LINEOUTP",50:"VRA1",
        51:"AGND",52:"MICIN1N",53:"MICIN1P",54:"VDD_SYS4",55:"VCC_PC",56:"PC1_SPI0_CS",57:"PC0_SPI0_CLK",
        58:"PC3_SPI0_MISO_BOOT1",59:"PC2_SPI0_MOSI_BOOT0",60:"PC5_SPI0_HOLD",61:"PC4_SPI0_WP",
        62:"VCC_PA_MCSI",63:"PA11",64:"PA10",65:"PA9",66:"PA8",67:"PA7",68:"PA6",69:"PA5",70:"PA4",
        71:"PA3",72:"PA2",73:"PA1",74:"PA0",75:"VDD_SYS5",76:"USB0_DP",77:"USB0_DM",78:"VCC33_USB",
        79:"VCC18_MDSI",80:"PD1_DSI_D0N",81:"PD2_DSI_D0P",82:"PD3_DSI_D1N",83:"PD4_DSI_D1P",
        84:"PD5_DSI_CKN",85:"PD6_DSI_CKP",86:"PD7",87:"PD8",88:"VDD_SYS6",89:"EPAD",
    }
    net: dict[int, str] = {
        2:"LCD_RST",3:"LCD_PWM",4:"LCD_EN",5:"3V3",6:"SD_D1",7:"SD_D0",8:"SD_CLK",9:"SD_CMD",
        10:"SD_D3",11:"SD_D2",12:"SD_DET",13:"CORE_0V93",14:"1V8",15:"XOUT",16:"XIN",
        17:"CORE_0V93",21:"I2C0_SCL",22:"3V3",23:"PMIC_IRQ_N",24:"RTC_INT_N",25:"E907_TX",
        26:"I2C0_SDA",30:"ACCEL_INT_N",31:"E907_RX",33:"CORE_0V93",34:"DRAM_1V5",35:"CORE_0V93",
        36:"DRAM_1V5",37:"1V8",38:"PMIC_SDA",39:"PMIC_SCL",40:"SD_PWR_EN",41:"STATUS_LED",
        42:"UART0_RX",43:"UART0_TX",44:"3V3",45:"WAKE_PULSE_N",46:"ADC_KEYS",47:"3V3",48:"1V8",
        50:"VRA1",51:"GND",54:"CORE_0V93",55:"3V3",56:"NAND_CS",57:"NAND_CLK",58:"NAND_MISO",
        59:"NAND_MOSI",60:"NAND_HOLD",61:"NAND_WP",62:"1V8",75:"CORE_0V93",76:"USB_DP",
        77:"USB_DM",78:"3V3",79:"1V8",80:"DSI_D0N",81:"DSI_D0P",82:"DSI_D1N",83:"DSI_D1P",
        84:"DSI_CKN",85:"DSI_CKP",88:"CORE_0V93",89:"GND",
    }
    return {str(i):(names[i], net.get(i)) for i in range(1, 90)}


def axp_pins() -> dict[str, tuple[str, str | None]]:
    names = {
        1:"CHGLED",2:"VREF",3:"GND",4:"FB3",5:"LX3",6:"VIN3",7:"VIN4",8:"LX4",9:"FB4",
        10:"CPUSLDO",11:"DLDO2_DC4SW",12:"BLDO1",13:"BLDOIN",14:"BLDO2",15:"ALDO4",16:"ALDO3",
        17:"ALDOIN",18:"ALDO1",19:"ALDO2",20:"DLDO1_DC1SW",21:"FB1",22:"LX1",23:"VIN1",24:"VIN2",
        25:"LX2",26:"FB2",27:"VBACKUP",28:"VRTC",29:"PWROK",30:"PWRON",31:"TS",32:"GPIO1_FB5_RTCLDO2",
        33:"BAT",34:"VSYS",35:"SW",36:"VMID",37:"VBUS",38:"IRQ",39:"SDA",40:"SCK",41:"EPAD",
    }
    net = {
        1:"CHGLED_N",2:"VREF",3:"GND",4:"CORE_0V93",5:"LX_CORE",6:"VSYS",7:"VSYS",8:"LX_DRAM",
        9:"DRAM_1V5",13:"3V3",17:"3V3",18:"1V8",21:"3V3",22:"LX_3V3",23:"VSYS",24:"VSYS",
        27:"GND",28:"RTC_3V3",29:"PMIC_PWROK",30:"PWRON_N",31:"BAT_NTC",33:"VBAT",34:"VSYS",
        37:"VBUS",38:"PMIC_IRQ_N",39:"PMIC_SDA",40:"PMIC_SCL",41:"GND",
    }
    return {str(i):(names[i], net.get(i)) for i in range(1, 42)}


def add(devs: list[Device], ref: str, value: str, fp: str, sheet: str, x: float, y: float,
        pins: dict[str, tuple[str, str | None]], **kw) -> Device:
    d = Device(ref, value, fp, sheet, x, y, pins, **kw)
    if not d.pads:
        if fp == "0402": d.pads = two_pad()
        elif fp == "0603": d.pads = two_pad(1.6, (.8, .95))
        elif fp == "IND_2x2": d.pads = two_pad(2.1, (1.2, 1.8))
        elif fp == "SOT23-3": d.pads = [Pad("1", -.95, -.95, .7, .9), Pad("2", .95, -.95, .7, .9), Pad("3", 0, .95, .7, .9)]
        elif fp == "SOT23-5": d.pads = [Pad("1",-1.2,-.95,.8,.65),Pad("2",-1.2,0,.8,.65),Pad("3",-1.2,.95,.8,.65),Pad("4",1.2,.95,.8,.65),Pad("5",1.2,-.95,.8,.65)]
        elif fp == "SC70-5": d.pads = [Pad("1",-1,-.65,.7,.35),Pad("2",-1,0,.7,.35),Pad("3",-1,.65,.7,.35),Pad("4",1,.65,.7,.35),Pad("5",1,-.65,.7,.35)]
        elif fp == "SOT23-6": d.pads = dual_pads(6, 2.4, .95, (.8,.65))
        elif fp == "SSOP-8": d.pads = dual_pads(8, 3.6, .65, (1.05,.35))
        elif fp == "WSON-8": d.pads = dual_pads(8, 6.4, 1.27, (1.4,.6))
        elif fp == "LGA-12": d.pads = lga12_pads()
        elif fp == "RTC-8": d.pads = dual_pads(8, 3.4, .5, (.65,.28))
        elif fp == "QFN40": d.pads = qfn_pads(40, 5.0, .4, "41", 3.1)
        elif fp == "QFN88": d.pads = qfn_pads(88, 9.0, .35, "89", 5.2)
        elif fp == "FPC20": d.pads = row_pads(20, .5, 1.2)
        elif fp == "USB4105": d.pads = usb4105_pads()
        elif fp == "MICROSD": d.pads = microsd_pads()
        elif fp == "SW_SIDE": d.pads = side_switch_pads()
        elif fp == "BAT3": d.pads = battery3_pads()
        elif fp == "HDR8": d.pads = test_header_pads(8)
        elif fp == "XTAL4": d.pads = crystal4_pads()
        elif fp == "D_SOD123": d.pads = two_pad(2.5, (1.2,1.1))
        elif fp == "LED0603": d.pads = two_pad(1.6, (.8,.9))
        else: raise ValueError(f"No footprint generator for {fp}")
    devs.append(d)
    return d


def devices() -> list[Device]:
    d: list[Device] = []
    passive = lambda a, b: {"1":("1",a), "2":("2",b)}

    usb_pins = {
        "A1":("GND", "GND"),"A4":("VBUS","VBUS"),"A5":("CC1","USB_CC1"),"A6":("DP1","USB_DP"),
        "A7":("DM1","USB_DM"),"A8":("SBU1",None),"A9":("VBUS","VBUS"),"A12":("GND","GND"),
        "B1":("GND","GND"),"B4":("VBUS","VBUS"),"B5":("CC2","USB_CC2"),"B6":("DP2","USB_DP"),
        "B7":("DM2","USB_DM"),"B8":("SBU2",None),"B9":("VBUS","VBUS"),"B12":("GND","GND"),
        "SH1":("SHIELD","GND"),"SH2":("SHIELD","GND"),"SH3":("SHIELD","GND"),"SH4":("SHIELD","GND"),
    }
    add(d,"J1","USB4105-GF-A-060","USB4105","power",29,106,usb_pins,mpn="USB4105-GF-A-060",lcsc="C3025063",datasheet="https://gct.co/files/drawings/usb4105.pdf")
    add(d,"R1","5.1k","0402","power",20,101,passive("USB_CC1","GND"),mpn="0402 5.1k 1%",lcsc="C25905")
    add(d,"R2","5.1k","0402","power",22,101,passive("USB_CC2","GND"),mpn="0402 5.1k 1%",lcsc="C25905")
    add(d,"U1","AXP2101","QFN40","power",18,85,axp_pins(),mpn="AXP2101",lcsc="C3036461",datasheet="https://www.x-powers.com/en.php/Info/product_detail/article_id/95")
    add(d,"L1","1uH/2A","IND_2x2","power",9,84,passive("LX_3V3","3V3"),mpn="1uH 2A shielded")
    add(d,"L2","1uH/2A","IND_2x2","power",9,88,passive("LX_CORE","CORE_0V93"),mpn="1uH 2A shielded")
    add(d,"L3","1uH/2A","IND_2x2","power",9,92,passive("LX_DRAM","DRAM_1V5"),mpn="1uH 2A shielded")
    for ref,val,x,y,a,b in [
        ("C1","22u",10,78,"VSYS","GND"),("C2","22u",14,78,"VSYS","GND"),("C3","1u",18,78,"VBAT","GND"),
        ("C4","22u",5,82,"3V3","GND"),("C5","22u",5,85,"3V3","GND"),
        ("C6","22u",5,88,"CORE_0V93","GND"),("C7","22u",5,91,"CORE_0V93","GND"),
        ("C8","22u",5,94,"DRAM_1V5","GND"),("C9","22u",5,97,"DRAM_1V5","GND"),
        ("C10","2.2u",13,93,"1V8","GND"),("C11","1u",13,96,"VREF","GND")]:
        add(d,ref,val,"0603","power",x,y,passive(a,b),mpn=f"0603 {val} X5R")
    add(d,"J2","1S LiPo + NTC","BAT3","power",45,99,{"1":("VBAT","VBAT"),"2":("NTC","BAT_NTC"),"3":("GND","GND")},mpn="S3B-PH-SM4-TB(LF)(SN)",lcsc="C265101")
    add(d,"SW5","POWER","SW_SIDE","power",55,82,{"1":("PWRON","PWRON_N"),"2":("PWRON","PWRON_N"),"3":("GND","GND")},mpn="GT-TC072B-H045-L1",lcsc="C5117859",rotation=90)
    add(d,"R3","4.7k","0402","power",22,78,passive("3V3","PMIC_IRQ_N"),lcsc="C25900")
    add(d,"R4","2.2k","0402","power",24,78,passive("3V3","PMIC_SCL"),lcsc="C25879")
    add(d,"R5","2.2k","0402","power",26,78,passive("3V3","PMIC_SDA"),lcsc="C25879")
    add(d,"D1","CHARGE","LED0603","power",30,82,passive("3V3","CHGLED_A"),mpn="0603 Green LED")
    add(d,"R6","2.2k","0402","power",34,82,passive("CHGLED_A","CHGLED_N"),lcsc="C25879")
    add(d,"U9","USBLC6-2SC6","SOT23-6","power",29,98,{"1":("I/O1","USB_DP"),"2":("GND","GND"),"3":("I/O2","USB_DM"),"4":("I/O2","USB_DM"),"5":("VBUS","VBUS"),"6":("I/O1","USB_DP")},mpn="USBLC6-2SC6",lcsc="C2827654",datasheet="https://www.st.com/resource/en/datasheet/usblc6-2.pdf",rotation=90)
    add(d,"D13","PESD4V0","0402","power",19.5,104,passive("USB_CC1","GND"),mpn="PESD4V0Y1BBSF")
    add(d,"D14","PESD4V0","0402","power",38.5,104,passive("USB_CC2","GND"),mpn="PESD4V0Y1BBSF")
    add(d,"C32","10u","0603","power",15,101,passive("VBUS","GND"),mpn="0603 10u X5R")
    add(d,"C33","1u","0603","power",13,90,passive("RTC_3V3","GND"),mpn="0603 1u X5R")

    add(d,"U2","V851s","QFN88","soc",30,56,v851_pins(),mpn="V851s",lcsc="C5365286",datasheet="https://www.allwinnertech.com/index.php?a=index&c=product&id=118")
    add(d,"Y1","24MHz 10ppm","XTAL4","soc",19,56,{"1":("XIN","XIN"),"2":("GND","GND"),"3":("XOUT","XOUT"),"4":("GND","GND")},mpn="24MHz 10ppm 3225")
    add(d,"C12","18p","0402","soc",17,53,passive("XIN","GND"))
    add(d,"C13","18p","0402","soc",17,59,passive("XOUT","GND"))
    bypass = [("3V3",5),("3V3",6),("1V8",7),("1V8",8),("CORE_0V93",9),("CORE_0V93",10),("CORE_0V93",11),("DRAM_1V5",12)]
    for idx,(rail,dy) in enumerate(bypass,14):
        slot=idx-14
        add(d,f"C{idx}","100n","0402","soc",40+(slot%2)*4,60+(slot//2)*3,passive(rail,"GND"),mpn="0402 100n X7R",lcsc="C1525")
    nandpins={"1":("CS","NAND_CS"),"2":("MISO","NAND_MISO"),"3":("WP","NAND_WP"),"4":("GND","GND"),"5":("MOSI","NAND_MOSI"),"6":("CLK","NAND_CLK"),"7":("HOLD","NAND_HOLD"),"8":("VCC","3V3")}
    # SPI0 is on the right side of U2 (PC0-PC5). Keep the NAND package in that
    # corridor so the maze does not have to wrap around the QFN via ring.
    add(d,"U3","W25N01GVZEIG","WSON-8","soc",50,62,nandpins,mpn="W25N01GVZEIG",lcsc="C907680",datasheet="https://www.winbond.com/hq/product/code-storage-flash-memory/qspinand-flash/?__locale=en&partNo=W25N01GV")
    add(d,"C22","100n","0402","soc",50,67,passive("3V3","GND"),lcsc="C1525")
    add(d,"R7","10k","0402","soc",50,75,passive("3V3","NAND_CS"))
    add(d,"R8","10k","0402","soc",53,75,passive("3V3","NAND_WP"))
    add(d,"R9","10k","0402","soc",56,75,passive("3V3","NAND_HOLD"))
    add(d,"J3","DEBUG POGO","HDR8","soc",44,72,{str(i+1):(n,net) for i,(n,net) in enumerate([("GND","GND"),("3V3","3V3"),("UART0_TX","UART0_TX"),("UART0_RX","UART0_RX"),("E907_TX","E907_TX"),("E907_RX","E907_RX"),("FEL_PC2","NAND_MOSI"),("PWRON_N","PWRON_N")])},note="1.27mm production/debug pads")
    add(d,"SW6","FEL","SW_SIDE","soc",55,91,{"1":("FEL_PC2","NAND_MOSI"),"2":("FEL_PC2","NAND_MOSI"),"3":("GND","GND")},mpn="GT-TC072B-H045-L1",lcsc="C5117859",rotation=90,note="Recessed recovery switch; straps PC2 low")
    add(d,"R10","10k","0402","soc",47,91,passive("3V3","NAND_MOSI"))
    add(d,"R28","10k","0402","soc",44,91,passive("3V3","NAND_MISO"),note="PC3 BOOT1 pull-up; SPI NAND boot")

    lis={"1":("SCL","I2C0_SCL"),"2":("CS","RTC_3V3"),"3":("SDO_SA0",None),"4":("SDA","I2C0_SDA"),"5":("NC",None),"6":("GND","GND"),"7":("RES","GND"),"8":("GND","GND"),"9":("VDD","RTC_3V3"),"10":("VDDIO","RTC_3V3"),"11":("INT2",None),"12":("INT1","ACCEL_INT_N")}
    add(d,"U4","LIS2DW12TR","LGA-12","sensors",8,19,lis,mpn="LIS2DW12TR",lcsc="C189624",datasheet="https://www.st.com/resource/en/datasheet/lis2dw12.pdf")
    rtc={"1":("CLKOUT",None),"2":("INT","RTC_INT_N"),"3":("SCL","I2C0_SCL"),"4":("SDA","I2C0_SDA"),"5":("VSS","GND"),"6":("VBACKUP","RTC_VBACKUP"),"7":("VDD","RTC_3V3"),"8":("EVI","RTC_EVI")}
    add(d,"U5","RV-3028-C7","RTC-8","sensors",15,19,rtc,mpn="RV-3028-C7-32.768kHz-1ppm-TA-QC",lcsc="C3019759",datasheet="https://www.microcrystal.com/fileadmin/Media/Products/RTC/App.Manual/RV-3028-C7_App-Manual.pdf")
    # SN74LVC1G123DCTR (DCT / SM8): 1=Q, 2=GND, 3=Cext, 4=Rext/Cext, 5=A, 6=B, 7=CLR, 8=VCC.
    mono={"1":("Q","WAKE_PULSE"),"2":("GND","GND"),"3":("CEXT","WAKE_CEXT"),"4":("REXT_CEXT","WAKE_REXT"),"5":("A","WAKE_REQ_N"),"6":("B","RTC_3V3"),"7":("CLR","RTC_3V3"),"8":("VCC","RTC_3V3")}
    add(d,"U6","SN74LVC1G123DCTR","SSOP-8","sensors",24,19,mono,mpn="SN74LVC1G123DCTR",datasheet="https://www.ti.com/lit/ds/symlink/sn74lvc1g123.pdf")
    add(d,"Q1","2N7002","SOT23-3","sensors",32,19,{"1":("G","WAKE_PULSE"),"2":("S","GND"),"3":("D","PWRON_N")},mpn="2N7002",lcsc="C8545")
    add(d,"Q2","2N7002","SOT23-3","sensors",38,19,{"1":("G","WAKE_PULSE"),"2":("S","GND"),"3":("D","WAKE_PULSE_N")},mpn="2N7002",lcsc="C8545")
    add(d,"R11","10k","0402","sensors",10,24,passive("RTC_3V3","WAKE_REQ_N"))
    add(d,"R12","820k","0402","sensors",24,24,passive("RTC_3V3","WAKE_REXT"))
    add(d,"C23","100n","0402","sensors",28,24,passive("WAKE_REXT","WAKE_CEXT"))
    add(d,"R13","10k","0402","sensors",15,24,passive("RTC_VBACKUP","GND"))
    add(d,"R14","10k","0402","sensors",17,24,passive("RTC_EVI","GND"))
    add(d,"R15","4.7k","0402","sensors",8,27,passive("3V3","I2C0_SCL"))
    add(d,"R16","4.7k","0402","sensors",10,27,passive("3V3","I2C0_SDA"))
    add(d,"R17","10k","0402","sensors",12,27,passive("3V3","RTC_INT_N"))
    add(d,"R18","10k","0402","sensors",14,27,passive("3V3","ACCEL_INT_N"))
    # Open-drain wake sources share the always-on request node through small-signal diodes.
    add(d,"D2","BAT54","D_SOD123","sensors",17,28,passive("RTC_INT_N","WAKE_REQ_N"),rotation=90)
    add(d,"D3","BAT54","D_SOD123","sensors",21,28,passive("ACCEL_INT_N","WAKE_REQ_N"),rotation=90)
    add(d,"C24","100n","0402","sensors",8,31,passive("RTC_3V3","GND"),lcsc="C1525")
    add(d,"C25","100n","0402","sensors",15,31,passive("RTC_3V3","GND"),lcsc="C1525")
    add(d,"C26","100n","0402","sensors",24,31,passive("RTC_3V3","GND"),lcsc="C1525")

    fpc={str(i):(f"PIN{i}",None) for i in range(1,21)}
    fpc.update({"6":("VCI","LCD_3V3"),"7":("IOVCC","LCD_3V3"),"8":("GND","GND"),"9":("D1P","DSI_D1P"),"10":("D1N","DSI_D1N"),"11":("GND","GND"),"12":("DCKP","DSI_CKP"),"13":("DCKN","DSI_CKN"),"14":("GND","GND"),"15":("D0P","DSI_D0P"),"16":("D0N","DSI_D0N"),"17":("GND","GND"),"18":("RESX","LCD_RST"),"19":("LEDK","LEDK"),"20":("LEDA","LEDA")})
    add(d,"J4","TFT-H035B22WVIST8N20_V3-0","FPC20","interfaces",30,39,fpc,mpn="FH12-20S-0.5SH(55)",lcsc="C596730",datasheet="https://www.hotlcd.com/productdetail/1973")
    tps={"1":("SW","BL_SW"),"2":("GND","GND"),"3":("FB","LEDK"),"4":("CTRL","LCD_PWM"),"5":("VIN","VSYS")}
    add(d,"U7","TPS61169DCKR","SC70-5","interfaces",45,42,tps,mpn="TPS61169DCKR",lcsc="C71045",datasheet="https://www.ti.com/lit/ds/symlink/tps61169.pdf")
    add(d,"L4","10uH/1.5A","IND_2x2","interfaces",45,36,passive("VSYS","BL_SW"))
    add(d,"D4","SS16","D_SOD123","interfaces",49,36,passive("BL_SW","LEDA"))
    add(d,"R19","2.55R 1%","0603","interfaces",49,42,passive("LEDK","GND"))
    add(d,"C27","1u/25V","0603","interfaces",46,32,passive("LEDA","GND"))
    add(d,"C28","100n","0402","interfaces",42,46,passive("VSYS","GND"))
    add(d,"U8","TPS22918DBVR","SOT23-5","interfaces",20,40,{"1":("VIN","3V3"),"2":("GND","GND"),"3":("ON","LCD_EN"),"4":("QOD",None),"5":("VOUT","LCD_3V3")},mpn="TPS22918DBVR")
    add(d,"C29","4.7u","0603","interfaces",16,40,passive("LCD_3V3","GND"))
    sd={"1":("DAT2","SD_D2"),"2":("DAT3","SD_D3"),"3":("CMD","SD_CMD"),"4":("VDD","SD_3V3"),"5":("CLK","SD_CLK"),"6":("VSS","GND"),"7":("DAT0","SD_D0"),"8":("DAT1","SD_D1"),"9":("CD","SD_DET"),"10":("SH","GND"),"11":("SH","GND"),"12":("SH","GND"),"13":("SH","GND")}
    add(d,"J5","MicroSD","MICROSD","interfaces",29,7,sd,mpn="MUP-M617-2",lcsc="C5205359")
    add(d,"Q3","AO3401A","SOT23-3","interfaces",41,8,{"1":("G","SD_PWR_GATE"),"2":("S","3V3"),"3":("D","SD_3V3")},mpn="AO3401A",lcsc="C15127")
    add(d,"R20","100k","0402","interfaces",45,8,passive("3V3","SD_PWR_GATE"))
    add(d,"R21","10k","0402","interfaces",49,8,passive("SD_PWR_EN","SD_PWR_GATE"))
    add(d,"C30","10u","0603","interfaces",39,12,passive("SD_3V3","GND"))
    for idx,(net,x) in enumerate([("SD_D2",36),("SD_D3",38.2),("SD_CMD",40.4),("SD_CLK",42.6),("SD_D0",44.8),("SD_D1",47.0),("SD_DET",49.2)],6):
        add(d,f"D{idx}","PESD4V0","0402","interfaces",x,15,passive(net,"GND"),mpn="PESD4V0Y1BBSF",rotation=270)
    for i,name,y in [(1,"UP",30),(2,"DOWN",40),(3,"OK",30),(4,"BACK",40)]:
        x=3 if i<3 else 55
        add(d,f"SW{i}",name,"SW_SIDE","interfaces",x,y,{"1":("KEY",f"KEY_{name}"),"2":("KEY",f"KEY_{name}"),"3":("GND","GND")},mpn="GT-TC072B-H045-L1",lcsc="C5117859",rotation=90 if i<3 else 270)
    add(d,"R22","100k","0402","interfaces",47,50,passive("1V8","ADC_KEYS"))
    add(d,"R23","0R","0402","interfaces",49,50,passive("KEY_UP","ADC_KEYS"))
    add(d,"R24","22k","0402","interfaces",51,50,passive("KEY_DOWN","ADC_KEYS"))
    add(d,"R25","47k","0402","interfaces",53,50,passive("KEY_OK","ADC_KEYS"))
    add(d,"R26","100k","0402","interfaces",55,50,passive("KEY_BACK","ADC_KEYS"))
    add(d,"C31","10n","0402","interfaces",45,50,passive("ADC_KEYS","GND"))
    add(d,"D5","STATUS","LED0603","interfaces",45,55,passive("STATUS_LED_A","GND"),mpn="0603 Blue LED")
    add(d,"R27","2.2k","0402","interfaces",42,55,passive("STATUS_LED","STATUS_LED_A"))
    return d


def symbol_library_entry(dev: Device) -> str:
    pin_items = sorted(dev.pins.items(), key=lambda kv: (not kv[0].isdigit(), int(kv[0]) if kv[0].isdigit() else kv[0]))
    nleft = (len(pin_items) + 1) // 2
    pitch = 1.27
    half_h = max(5.08, (nleft - 1) * pitch / 2 + 1.27)
    lines = [f'\t\t(symbol {q("Sameat:" + dev.ref + "_" + dev.value)}', '\t\t\t(pin_names (offset 0.8))', '\t\t\t(exclude_from_sim no)', '\t\t\t(in_bom yes)', '\t\t\t(on_board yes)']
    for key,val in [("Reference",dev.ref[0]),("Value",dev.value),("Footprint",f"Sameat:{dev.footprint}"),("Datasheet",dev.datasheet),("Description",dev.note or dev.mpn)]:
        lines += [f'\t\t\t(property {q(key)} {q(val)}', '\t\t\t\t(at 0 0 0)', '\t\t\t\t(effects (font (size 1.0 1.0)) (hide yes))', '\t\t\t)']
    lines += [f'\t\t\t(symbol {q(dev.ref + "_0_1")}', f'\t\t\t\t(rectangle (start -12.7 {-half_h:.3f}) (end 12.7 {half_h:.3f}) (stroke (width 0.254) (type default)) (fill (type background)))', '\t\t\t)']
    lines += [f'\t\t\t(symbol {q(dev.ref + "_1_1")}']
    for idx,(num,(name,_net)) in enumerate(pin_items):
        if idx < nleft:
            yy = -((nleft - 1) * pitch / 2) + idx * pitch
            at = f'-15.24 {yy:.3f} 0'
        else:
            j=idx-nleft; nr=len(pin_items)-nleft
            yy = -((nr - 1) * pitch / 2) + j * pitch
            at = f'15.24 {yy:.3f} 180'
        lines += [f'\t\t\t\t(pin passive line (at {at}) (length 2.54)', f'\t\t\t\t\t(name {q(name)} (effects (font (size .8 .8))))', f'\t\t\t\t\t(number {q(num)} (effects (font (size .8 .8))))', '\t\t\t\t)']
    lines += ['\t\t\t)', '\t\t)']
    return "\n".join(lines)


def schematic_for_sheet(sheet: str, devs: list[Device], root_uuid: str, sheet_uuid: str) -> str:
    suid=uid(f"schematic-{sheet}")
    title={"power":"01 Power / Charger / PMIC","soc":"02 V851s / Boot / Storage","sensors":"03 Always-on Sensors / Wake","interfaces":"04 Display / SD / Buttons"}[sheet]
    selected=[d for d in devs if d.sheet==sheet]
    out=['(kicad_sch','\t(version 20250114)','\t(generator "eeschema")','\t(generator_version "9.0")',f'\t(uuid {q(suid)})','\t(paper "A3")', '\t(title_block', f'\t\t(title {q(title)})','\t\t(date "2026-09-04")','\t\t(rev "V1.0-EVT1")','\t\t(company "Sameat")','\t\t(comment 1 "Reference-derived engineering validation design")','\t\t(comment 2 "NOT physically validated; review before fabrication")','\t)', '\t(lib_symbols']
    out += [symbol_library_entry(d) for d in selected]
    out += ['\t)']
    # Wide grid; the V851s block receives an entire column.
    placements: dict[str,tuple[float,float]]={}
    if sheet=="soc":
        placements["U2"]=(80,100)
        small=[d for d in selected if d.ref!="U2"]
        for i,dv in enumerate(small): placements[dv.ref]=(25+(i%3)*55,25+(i//3)*28)
    else:
        for i,dv in enumerate(selected): placements[dv.ref]=(25+(i%4)*65,25+(i//4)*30)
    for dev in selected:
        x,y=placements[dev.ref]
        pin_items=sorted(dev.pins.items(), key=lambda kv:(not kv[0].isdigit(), int(kv[0]) if kv[0].isdigit() else kv[0]))
        nleft=(len(pin_items)+1)//2; pitch=1.27
        duid=uid(f"symbol-{dev.ref}")
        out += ['\t(symbol',f'\t\t(lib_id {q("Sameat:" + dev.ref + "_" + dev.value)})',f'\t\t(at {x:.3f} {y:.3f} 0)','\t\t(unit 1)','\t\t(exclude_from_sim no)','\t\t(in_bom yes)','\t\t(on_board yes)',f'\t\t(dnp {"yes" if dev.dnp else "no"})',f'\t\t(uuid {q(duid)})']
        for key,val,px,py,hide in [("Reference",dev.ref,x,y-9,False),("Value",dev.value,x,y-7.5,False),("Footprint",f"Sameat:{dev.footprint}",x,y,True),("Datasheet",dev.datasheet,x,y,True),("MPN",dev.mpn,x,y,True),("LCSC",dev.lcsc,x,y,True),("Description",dev.note,x,y,True)]:
            out += [f'\t\t(property {q(key)} {q(val)}',f'\t\t\t(at {px:.3f} {py:.3f} 0)',f'\t\t\t(effects (font (size 1 1)){" (hide yes)" if hide else ""})','\t\t)']
        for num,_ in pin_items: out += [f'\t\t(pin {q(num)} (uuid {q(uid(f"pin-{dev.ref}-{num}"))}))']
        out += ['\t\t(instances',f'\t\t\t(project {q("portable_display_epass")}',f'\t\t\t\t(path {q("/"+root_uuid+"/"+sheet_uuid)} (reference {q(dev.ref)}) (unit 1))','\t\t\t)','\t\t)','\t)']
        for idx,(num,(_name,net)) in enumerate(pin_items):
            if idx<nleft:
                yy=y-((nleft-1)*pitch/2)+idx*pitch; xx=x-15.24; orient=180
            else:
                j=idx-nleft; nr=len(pin_items)-nleft
                yy=y-((nr-1)*pitch/2)+j*pitch; xx=x+15.24; orient=0
            if net:
                out += [f'\t(global_label {q(net)} (shape passive) (at {xx:.3f} {yy:.3f} {orient}) (effects (font (size .8 .8)) (justify {"right" if orient==180 else "left"})) (uuid {q(uid(f"label-{dev.ref}-{num}"))}))']
            else:
                out += [f'\t(no_connect (at {xx:.3f} {yy:.3f}) (uuid {q(uid(f"nc-{dev.ref}-{num}"))}))']
    out += [f'\t(sheet_instances (path {q("/"+root_uuid+"/"+sheet_uuid)} (page "2")))','\t(embedded_fonts no)',')']
    return "\n".join(out)+"\n"


def root_schematic() -> tuple[str, dict[str,str]]:
    root_uuid=uid("root-schematic")
    sheets={name:uid(f"root-sheet-{name}") for name in ("power","soc","sensors","interfaces")}
    out=['(kicad_sch','\t(version 20250114)','\t(generator "eeschema")','\t(generator_version "9.0")',f'\t(uuid {q(root_uuid)})','\t(paper "A4")','\t(title_block','\t\t(title "Portable Display ePass")','\t\t(date "2026-09-04")','\t\t(rev "V1.0-EVT1")','\t\t(company "Sameat")','\t\t(comment 1 "V851s + AXP2101 + 3.5in MIPI DSI")','\t\t(comment 2 "EVT design: not physically validated")','\t)','\t(lib_symbols)']
    info=[("power","01_power.kicad_sch",25,35),("soc","02_soc_v851s.kicad_sch",100,35),("sensors","03_sensors.kicad_sch",25,95),("interfaces","04_interfaces.kicad_sch",100,95)]
    for name,file,x,y in info:
        su=sheets[name]
        out += ['\t(sheet',f'\t\t(at {x} {y})','\t\t(size 55 35)','\t\t(exclude_from_sim no)','\t\t(in_bom yes)','\t\t(on_board yes)','\t\t(dnp no)', '\t\t(stroke (width .1524) (type solid))','\t\t(fill (color 0 0 0 0))',f'\t\t(uuid {q(su)})',f'\t\t(property "Sheetname" {q(name.upper())} (at {x} {y-1} 0) (effects (font (size 1.27 1.27)) (justify left bottom)))',f'\t\t(property "Sheetfile" {q(file)} (at {x} {y+36} 0) (effects (font (size 1.27 1.27)) (justify left top)))','\t)']
    pages=" ".join(f'(path {q("/"+sheets[name])} (page "{i+2}"))' for i,name in enumerate(("power","soc","sensors","interfaces")))
    out += ['\t(text "V1.0-EVT1 - reference-derived hardware design\\nNo radio / no audio / no touch / no AOD\\nSee docs/ for pin map, power tree and bring-up checklist." (exclude_from_sim no) (at 25 150 0) (effects (font (size 1.27 1.27)) (justify left top)) (uuid "'+uid('root-note')+'"))',f'\t(sheet_instances (path "/" (page "1")) {pages})','\t(embedded_fonts no)',')']
    return "\n".join(out)+"\n",sheets


def write_local_footprints(devs: list[Device]) -> None:
    LIB.mkdir(exist_ok=True)
    kinds={d.footprint:d.pads for d in devs}
    for name,pads in kinds.items():
        x0=min(p.x-p.sx/2 for p in pads)-.1; x1=max(p.x+p.sx/2 for p in pads)+.1
        y0=min(p.y-p.sy/2 for p in pads)-.1; y1=max(p.y+p.sy/2 for p in pads)+.1
        lines=[f'(footprint {q(name)}','\t(version 20240108)','\t(generator "sameat-evt1-generator")','\t(layer "F.Cu")',f'\t(property "Reference" "REF**" (at 0 {y0-1:.3f} 0) (layer "F.SilkS") (hide yes) (effects (font (size 1 1) (thickness .15))))',f'\t(property "Value" {q(name)} (at 0 {y1+1:.3f} 0) (layer "F.Fab") (effects (font (size .8 .8) (thickness .12))))','\t(attr smd)',f'\t(fp_rect (start {x0:.3f} {y0:.3f}) (end {x1:.3f} {y1:.3f}) (stroke (width .1) (type default)) (fill none) (layer "F.Fab"))',f'\t(fp_rect (start {x0:.3f} {y0:.3f}) (end {x1:.3f} {y1:.3f}) (stroke (width .05) (type default)) (fill none) (layer "F.CrtYd"))','\t(fp_text user "${REFERENCE}" (at 0 0 0) (layer "F.Fab") (effects (font (size .7 .7) (thickness .1))))']
        for i,p in enumerate(pads):
            layer=' '.join(q(x) for x in p.layers)
            if p.kind=="thru_hole":
                lines.append(f'\t(pad {q(p.number)} thru_hole {p.shape} (at {p.x:.4f} {p.y:.4f} {p.angle:g}) (size {p.sx:.4f} {p.sy:.4f}) (drill {p.drill or .3:.4f}) (layers {layer}))')
            else:
                rr=' (roundrect_rratio .2)' if p.shape=='roundrect' else ''
                lines.append(f'\t(pad {q(p.number)} smd {p.shape} (at {p.x:.4f} {p.y:.4f} {p.angle:g}) (size {p.sx:.4f} {p.sy:.4f}) (layers {layer}){rr})')
        lines.append(')')
        (LIB/f"{name}.kicad_mod").write_text("\n".join(lines)+"\n")


def abs_pad(dev: Device, pad: Pad) -> tuple[float,float]:
    a=math.radians(dev.rotation); ca,sa=math.cos(a),math.sin(a)
    return dev.x+pad.x*ca-pad.y*sa, dev.y+pad.x*sa+pad.y*ca


def _seg(x1,y1,x2,y2,width,layer,net,net_ids,tag) -> str:
    return f'\t(segment (start {x1:.4f} {y1:.4f}) (end {x2:.4f} {y2:.4f}) (width {width:.3f}) (layer {q(layer)}) (net {net_ids[net]}) (uuid {q(uid(tag))}))'


def _circle_rect_clear(cx,cy,cr,x0,y0,x1,y1) -> float:
    qx=min(max(cx,x0),x1); qy=min(max(cy,y0),y1)
    return math.hypot(cx-qx,cy-qy)-cr


class CopperMap:
    def __init__(self, devs: list[Device]):
        self.pads=[]  # (x0,y0,x1,y1,net,ref,pn)
        self.vias: list[tuple[float,float,float,str]]=[]  # x,y,radius,net
        for d in devs:
            for p in d.pads:
                px,py=abs_pad(d,p)
                net=d.pins.get(p.number,("",None))[1]
                self.pads.append((px-p.sx/2,py-p.sy/2,px+p.sx/2,py+p.sy/2,net or "",d.ref,p.number))
                if p.kind=="thru_hole":
                    self.vias.append((px,py,max(p.sx,p.sy)/2,net or ""))

    def via_ok(self, x: float, y: float, net: str) -> tuple[bool,str]:
        if x<1.2 or y<1.2 or x>56.8 or y>108.8:
            return False, f"outside board at ({x:.2f},{y:.2f})"
        vr=VIA_SIZE/2
        for vx,vy,rr,n2 in self.vias:
            need = vr+rr+(HD_CLEAR if n2!=net else 0.05)
            if math.hypot(x-vx,y-vy)<need:
                return False, f"via collision with {n2 or 'copper'} at ({vx:.2f},{vy:.2f})"
        for x0,y0,x1,y1,n2,ref,pn in self.pads:
            gap=_circle_rect_clear(x,y,vr,x0,y0,x1,y1)
            # Hole-to-copper uses 0.25 mm board hole clearance to foreign pads.
            hole_gap=_circle_rect_clear(x,y,VIA_DRILL/2,x0,y0,x1,y1)
            if n2==net:
                if hole_gap<0.05:
                    return False, f"via on own pad {ref}.{pn}"
                continue
            if gap<HD_CLEAR:
                return False, f"via-pad clearance {gap:.3f} mm to {ref}.{pn}[{n2}]"
            if hole_gap<0.25:
                return False, f"hole clearance {hole_gap:.3f} mm to {ref}.{pn}[{n2}] (need 0.25)"
        return True, "ok"

    def add_via(self, x, y, net):
        self.vias.append((x,y,VIA_SIZE/2,net))


def pad_outward(dev: Device, pad: Pad) -> tuple[float,float]:
    if abs(pad.x)>=abs(pad.y):
        return math.copysign(1,pad.x) if pad.x else 0.0, 0.0
    return 0.0, math.copysign(1,pad.y) if pad.y else -1.0


def deterministic_fanout_and_routes(devs: list[Device], net_ids: dict[str,int]) -> tuple[list[str],dict]:
    """Staggered V851s/AXP fanout plus explicit non-display routes. No maze."""
    copper=CopperMap(devs)
    items: list[str]=[]
    fanout_via: dict[tuple[str,str],tuple[float,float]]={}  # (ref,pin)->(x,y)
    report={"v851_ok":[], "v851_skip_display":[], "v851_nc":[], "v851_fail":[], "routes":{}}

    def place_via(net, x, y, tag):
        ok,why=copper.via_ok(x,y,net)
        if not ok:
            return False, why
        copper.add_via(x,y,net)
        items.append(_via(x,y,net,net_ids,tag))
        return True, "ok"

    def stub_and_via(dev: Device, pad: Pad, net: str, rings: tuple[float,...], ring_i: int, tag: str, force_dir=None):
        px,py=abs_pad(dev,pad)
        if force_dir:
            ux,uy=force_dir
        else:
            ux,uy=pad_outward(dev,pad)
        a=math.radians(dev.rotation); ca,sa=math.cos(a),math.sin(a)
        rx,ry=ux*ca-uy*sa, ux*sa+uy*ca
        order=[rings[ring_i%len(rings)]]+[r for i,r in enumerate(rings) if i!=ring_i%len(rings)]
        last_why="no ring tried"
        for dist in order:
            tx,ty=px+rx*dist, py+ry*dist
            ok,why=place_via(net,tx,ty,f"fo-via-{tag}")
            if ok:
                items.append(_seg(px,py,tx,ty,HD_WIDTH if dev.ref=="U2" else NORM_WIDTH,"F.Cu",net,net_ids,f"fo-stub-{tag}"))
                fanout_via[(dev.ref,pad.number)]=(tx,ty)
                return True, f"ring {dist:.2f} mm"
            last_why=why
        return False, last_why

    u2=next(d for d in devs if d.ref=="U2")
    for pad in u2.pads:
        net=u2.pins.get(pad.number,("",None))[1]
        name=u2.pins.get(pad.number,(pad.number,None))[0]
        if pad.number=="89":
            report["v851_nc"].append({"pin":pad.number,"name":name,"net":"GND-EP","note":"EP uses thermal vias"})
            continue
        if not net:
            report["v851_nc"].append({"pin":pad.number,"name":name,"net":None})
            continue
        if net in DISPLAY_NETS:
            report["v851_skip_display"].append({"pin":pad.number,"name":name,"net":net})
            continue
        ring=int(pad.number)%3
        ok,why=stub_and_via(u2,pad,net,V851_RINGS,ring,f"U2-{pad.number}")
        rec={"pin":pad.number,"name":name,"net":net,"why":why}
        (report["v851_ok"] if ok else report["v851_fail"]).append(rec)

    u1=next(d for d in devs if d.ref=="U1")
    axp_rings=(1.00,1.70)
    for pad in u1.pads:
        net=u1.pins.get(pad.number,("",None))[1]
        if not net or pad.number=="41":
            continue
        stub_and_via(u1,pad,net,axp_rings,int(pad.number)%2,f"U1-{pad.number}")

    def fan_part(ref: str, rings=(0.90,1.40), skip_th=True):
        dev=next(d for d in devs if d.ref==ref)
        for pad in dev.pads:
            net=dev.pins.get(pad.number,("",None))[1]
            if not net or net in DISPLAY_NETS:
                continue
            if skip_th and pad.kind=="thru_hole":
                fanout_via[(dev.ref,pad.number)]=abs_pad(dev,pad)
                continue
            if (dev.ref,pad.number) in fanout_via:
                continue
            stub_and_via(dev,pad,net,rings,hash(pad.number)%len(rings),f"{ref}-{pad.number}")

    for ref in ("U3","J5","U9","J3","U4","U5","U6"):
        fan_part(ref)

    def via_of(ref, pin) -> tuple[float,float] | None:
        return fanout_via.get((ref,str(pin)))

    def manhattan(net, a, b, layer, width, tag):
        if a is None or b is None:
            report["routes"][tag]="missing fanout via"
            return False
        x1,y1=a; x2,y2=b
        mid=(x2,y1)
        items.append(_seg(x1,y1,mid[0],mid[1],width,layer,net,net_ids,tag+"-h"))
        items.append(_seg(mid[0],mid[1],x2,y2,width,layer,net,net_ids,tag+"-v"))
        report["routes"][tag]="ok"
        return True

    # Board-level buses are not emitted here: L-shaped B.Cu runs crossed the
    # staggered via field and shorted. Fanout vias remain the deliverable.
    report["routes"]["nand"]="fanout only; B.Cu trunk omitted (via-field shorts)"
    report["routes"]["sd"]="fanout only; B.Cu trunk omitted (via-field shorts)"
    report["routes"]["usb-pair"]="fanout only; pair trunk omitted (via-field / U9 pad shorts)"
    report["routes"]["i2c"]="fanout only"
    report["routes"]["uart"]="fanout only"
    report["routes"]["pmic"]="fanout only"

    OUT.mkdir(parents=True,exist_ok=True)
    (OUT/"fanout_report.json").write_text(json.dumps(report, indent=2))
    return items, report


def footprint_instance(dev: Device, net_ids: dict[str,int]) -> str:
    x0=min(p.x-p.sx/2 for p in dev.pads)-.1; x1=max(p.x+p.sx/2 for p in dev.pads)+.1
    y0=min(p.y-p.sy/2 for p in dev.pads)-.1; y1=max(p.y+p.sy/2 for p in dev.pads)+.1
    lines=[f'\t(footprint {q("Sameat:"+dev.footprint)}','\t\t(layer "F.Cu")',f'\t\t(at {dev.x:.4f} {dev.y:.4f} {dev.rotation:g})',f'\t\t(uuid {q(uid("fp-"+dev.ref))})',f'\t\t(property "Reference" {q(dev.ref)} (at 0 {y0-1:.3f} {dev.rotation:g}) (layer "F.SilkS") (hide yes) (effects (font (size 1 1) (thickness .15))))',f'\t\t(property "Value" {q(dev.value)} (at 0 {y1+1:.3f} {dev.rotation:g}) (layer "F.Fab") (effects (font (size .7 .7) (thickness .1))))',f'\t\t(property "MPN" {q(dev.mpn)} (at 0 0 0) (layer "F.Fab") (hide yes) (effects (font (size 1 1))))',f'\t\t(property "LCSC" {q(dev.lcsc)} (at 0 0 0) (layer "F.Fab") (hide yes) (effects (font (size 1 1))))',f'\t\t(path {q("/"+uid("root-schematic")+"/"+uid("root-sheet-"+dev.sheet)+"/"+uid("symbol-"+dev.ref))})',f'\t\t(attr smd{" dnp" if dev.dnp else ""})',f'\t\t(fp_rect (start {x0:.3f} {y0:.3f}) (end {x1:.3f} {y1:.3f}) (stroke (width .1) (type default)) (fill none) (layer "F.Fab"))',f'\t\t(fp_rect (start {x0:.3f} {y0:.3f}) (end {x1:.3f} {y1:.3f}) (stroke (width .05) (type default)) (fill none) (layer "F.CrtYd"))',f'\t\t(fp_text user "${{REFERENCE}}" (at 0 0 {dev.rotation:g}) (layer "F.Fab") (effects (font (size .7 .7) (thickness .1))))']
    for p in dev.pads:
        net=dev.pins.get(p.number,("",None))[1]
        netstr=f' (net {net_ids[net]} {q(net)})' if net else ''
        fn=dev.pins.get(p.number,(p.number,None))[0]
        layers=' '.join(q(x) for x in p.layers)
        if p.kind=="thru_hole":
            lines.append(f'\t\t(pad {q(p.number)} thru_hole {p.shape} (at {p.x:.4f} {p.y:.4f} {p.angle:g}) (size {p.sx:.4f} {p.sy:.4f}) (drill {p.drill or .3:.4f}) (layers {layers}){netstr} (pinfunction {q(fn)}) (pintype "passive") (uuid {q(uid(f"pad-{dev.ref}-{p.number}-{p.x}-{p.y}"))}))')
        else:
            rr=' (roundrect_rratio .2)' if p.shape=='roundrect' else ''
            lines.append(f'\t\t(pad {q(p.number)} smd {p.shape} (at {p.x:.4f} {p.y:.4f} {p.angle:g}) (size {p.sx:.4f} {p.sy:.4f}) (layers {layers}){rr}{netstr} (pinfunction {q(fn)}) (pintype "passive") (uuid {q(uid(f"pad-{dev.ref}-{p.number}-{p.x}-{p.y}"))}))')
    lines.append('\t)')
    return "\n".join(lines)


@dataclass(frozen=True)
class Terminal:
    net: str
    x: float
    y: float
    radius: float = .30
    active: bool = True
    dx: float = 0.0
    dy: float = 0.0


def snap(value: float, grid: float = .1) -> float:
    return round(value / grid) * grid


def _via(x: float, y: float, net: str, net_ids: dict[str,int], tag: str) -> str:
    return f'\t(via (at {x:.4f} {y:.4f}) (size {VIA_SIZE:.2f}) (drill {VIA_DRILL:.2f}) (layers "F.Cu" "B.Cu") (net {net_ids[net]}) (uuid {q(uid(tag))}))'


def escape_fanout(devs: list[Device], net_ids: dict[str,int]) -> tuple[list[str],dict[str,list[Terminal]]]:
    """Fan non-display pads to 0.40/0.20 mm vias.

    Display-island nets are not fanned: MIPI/FPC/backlight stay as ratsnest.
    QFN pins use a 3-ring stagger so 0.40 mm vias clear a 0.35 mm pitch.
    """
    items: list[str]=[]
    terms: dict[str,list[Terminal]]={}
    used: list[tuple[float,float]]=[]
    min_sep = VIA_SIZE + 0.13

    def place_via(net: str, tx: float, ty: float, tag: str) -> tuple[float,float] | None:
        tx,ty=snap(tx),snap(ty)
        for ox,oy in used:
            if math.hypot(tx-ox,ty-oy)<min_sep:
                return None
        used.append((tx,ty))
        items.append(_via(tx,ty,net,net_ids,tag))
        terms.setdefault(net,[]).append(Terminal(net,tx,ty,VIA_SIZE,True))
        return tx,ty

    for dev in devs:
        for pad in dev.pads:
            net=dev.pins.get(pad.number,("",None))[1]
            if not net or net in DISPLAY_NETS:
                continue
            # Signal fanout on 0.35 mm QFN still shorts 0.40 mm vias. Only drop
            # vias that attach power pins to the pours; route signals in pcbnew.
            if dev.footprint in ("QFN40","QFN88","USB4105","MICROSD","LGA-12") and net not in PLANE_NETS:
                continue
            px,py=abs_pad(dev,pad)
            if pad.kind=="thru_hole":
                terms.setdefault(net,[]).append(Terminal(net,snap(px),snap(py),max(pad.sx,pad.sy)))
                continue
            if dev.footprint in ("FPC20","USB4105"):
                continue
            lx,ly=pad.x,pad.y
            if dev.footprint in ("QFN40","QFN88") and pad.number in ("41","89"):
                continue
            if net in {"USB_DP","USB_DM"} and dev.footprint=="QFN88":
                vx,vy=(1.0 if net=="USB_DP" else -1.0),0.0
            elif abs(lx)>abs(ly):
                vx,vy=math.copysign(1,lx),0.0
            elif math.hypot(lx,ly)<.01:
                vx,vy=0.0,-1.0
            else:
                vx,vy=0.0,math.copysign(1,ly)
            a=math.radians(dev.rotation); ca,sa=math.cos(a),math.sin(a)
            rx,ry=vx*ca-vy*sa, vx*sa+vy*ca
            if dev.footprint in ("QFN40","QFN88") and pad.number.isdigit():
                ring=int(pad.number)%3
                distance=1.50+ring*0.95
            elif dev.footprint=="MICROSD" and pad.number.isdigit() and int(pad.number)<=9:
                vx,vy=0.0,1.0
                rx,ry=vx,vy
                distance=1.1
            elif dev.footprint=="USB4105":
                if net not in {"VBUS","GND"}:
                    continue
                vx,vy=0.0,-1.0
                rx,ry=vx,vy
                distance=1.6
            else:
                distance=0.85
            width=.20 if net in PLANE_NETS else .12
            placed=None
            for extra in (0.0,0.4,0.8,1.2):
                tx=px+rx*(distance+extra); ty=py+ry*(distance+extra)
                if math.hypot(px-tx,py-ty)>.05:
                    # probe occupancy before committing the stub
                    trial=True
                    ttx,tty=snap(tx),snap(ty)
                    for ox,oy in used:
                        if math.hypot(ttx-ox,tty-oy)<min_sep:
                            trial=False; break
                    if not trial:
                        continue
                    items.append(f'\t(segment (start {px:.4f} {py:.4f}) (end {ttx:.4f} {tty:.4f}) (width {width:.3f}) (layer "F.Cu") (net {net_ids[net]}) (uuid {q(uid(f"escape-{dev.ref}-{pad.number}"))}))')
                    placed=place_via(net,ttx,tty,f"escape-via-{dev.ref}-{pad.number}")
                    if placed:
                        break
            _=placed
    return items,terms


def autoroute(terminals: dict[str,list[Terminal]], net_ids: dict[str,int]) -> tuple[list[str],dict[str,float]]:
    """Deterministic two-layer maze router for the escaped low-speed nets.

    In1.Cu remains an uninterrupted ground reference. B.Cu and In2.Cu carry
    orthogonal/maze-routed signals; every layer change is a plated through via.
    """
    grid=.2; nx=int(58/grid)+1; ny=int(110/grid)+1
    layers=("B.Cu","In2.Cu")
    occ=[{} for _ in layers]  # cell -> set of occupying nets

    def mark(layer: int, ix: int, iy: int, net: str, radius_cells: float) -> None:
        rr=math.ceil(radius_cells)
        for dx in range(-rr,rr+1):
            for dy in range(-rr,rr+1):
                if dx*dx+dy*dy <= radius_cells*radius_cells+1e-9:
                    occ[layer].setdefault((ix+dx,iy+dy),set()).add(net)

    def mark_routed(layer: int, ix: int, iy: int, net: str, radius_cells: float) -> None:
        """Add routed copper while preserving pre-reserved foreign escapes."""
        rr=math.ceil(radius_cells)
        for dx in range(-rr,rr+1):
            for dy in range(-rr,rr+1):
                if dx*dx+dy*dy > radius_cells*radius_cells+1e-9: continue
                cell=(ix+dx,iy+dy); owners=occ[layer].get(cell)
                if owners and net not in owners: continue
                occ[layer].setdefault(cell,set()).add(net)

    # Escape vias occupy both routing layers. Do not pre-reserve long
    # outward corridors: those walls boxed later nets inside the QFN ring.
    for net,ts in terminals.items():
        for t in ts:
            ix=round(t.x/grid); iy=round(t.y/grid)
            radius=(t.radius/2+.10+.06)/grid
            for layer in range(2): mark(layer,ix,iy,net,radius)
    # Keep the high-speed groups leaving each endpoint toward the connector-to-
    # SoC corridor.  Without these one-cell guards a shortest-path search can
    # wrap one member around the back of an adjacent fine-pitch terminal.
    for net,ts in terminals.items():
        if not (net.startswith("DSI_") or net.startswith("USB_D")): continue
        ys=[round(t.y/grid) for t in ts]; ymin,ymax=min(ys),max(ys)
        for t in ts:
            ix=round(t.x/grid); iy=round(t.y/grid)
            outside=iy-2 if iy==ymin else (iy+2 if iy==ymax else None)
            if outside is not None:
                for layer in range(2): mark(layer,ix,outside,"#HS_GUARD",0.0)
    # Mechanical holes are hard obstacles.
    for x,y in ((3,3),(55,3),(3,107),(55,107)):
        for layer in range(2): mark(layer,round(x/grid),round(y/grid),"#HOLE",(1.2+.15+.06)/grid)
    # Leave the SoC-to-FPC corridor empty for a later OLED MIPI bundle.
    for ix in range(round(24/grid), round(36/grid)+1):
        for iy in range(round(40/grid), round(50/grid)+1):
            for layer in range(2): mark(layer,ix,iy,"#DISPLAY_KEEP",0.0)

    def free(state: tuple[int,int,int], net: str) -> bool:
        ix,iy,layer=state
        if ix<2 or iy<2 or ix>nx-3 or iy>ny-3: return False
        return all(owner==net for owner in occ[layer].get((ix,iy),()))

    def route_one(starts: set[tuple[int,int,int]], targets: set[tuple[int,int,int]], net: str) -> list[tuple[int,int,int]] | None:
        txs=[s[0] for s in targets]; tys=[s[1] for s in targets]
        bx0,bx1=min(txs),max(txs); by0,by1=min(tys),max(tys)
        def heuristic(s: tuple[int,int,int]) -> int:
            x,y,_=s
            return max(bx0-x,0,x-bx1)+max(by0-y,0,y-by1)
        queue=[]; score={}; came={}; serial=0
        for s in starts:
            score[s]=0; heapq.heappush(queue,(heuristic(s),0,serial,s)); serial+=1
        hit=None; expansions=0
        while queue and expansions<800000:
            _f,g,_s,cur=heapq.heappop(queue)
            if g!=score.get(cur): continue
            if cur in targets: hit=cur; break
            expansions+=1
            x,y,layer=cur
            candidates=[((x+1,y,layer),1),((x-1,y,layer),1),((x,y+1,layer),1),((x,y-1,layer),1),((x,y,1-layer),14)]
            for nxt,cost in candidates:
                if not free(nxt,net): continue
                if nxt[2]!=layer and not free((x,y,layer),net): continue
                ng=g+cost
                if ng<score.get(nxt,10**18):
                    score[nxt]=ng; came[nxt]=cur
                    heapq.heappush(queue,(ng+heuristic(nxt),ng,serial,nxt)); serial+=1
        if hit is None: return None
        path=[hit]
        while path[-1] not in starts: path.append(came[path[-1]])
        path.reverse(); return path

    skip=PLANE_NETS | DISPLAY_NETS
    work=[]
    for net,ts in terminals.items():
        unique={(round(t.x/grid),round(t.y/grid)) for t in ts if t.active}
        if net in skip or len(unique)<2: continue
        span=(max(x for x,_ in unique)-min(x for x,_ in unique))+(max(y for _,y in unique)-min(y for _,y in unique))
        work.append((net,unique,span))
    power_first={"1V8","CORE_0V93","DRAM_1V5","RTC_3V3","VSYS","VBAT","VBUS","SD_3V3"}
    sd_bus={"SD_D0","SD_D1","SD_D2","SD_D3","SD_CMD","SD_CLK","SD_DET"}
    nand_bus={"NAND_CS","NAND_CLK","NAND_MISO","NAND_MOSI","NAND_HOLD","NAND_WP"}
    display_ctrl={"LCD_PWM","LCD_EN","LCD_RST"}
    pmic_bus={"PMIC_SCL","PMIC_SDA","PMIC_IRQ_N"}
    priority=lambda net: 0 if net=="LCD_RST" else (1 if net.startswith("USB_D") else (2 if net=="VBUS" else (3 if net=="VBAT" else (4 if net=="SD_3V3" else (5 if net=="SD_PWR_EN" else (6 if net in sd_bus else (7 if net.startswith("DSI_") else (8 if net in nand_bus else (9 if net=="1V8" else (10 if net=="CORE_0V93" else (11 if net in pmic_bus else (12 if net in display_ctrl else (13 if net in power_first else 14)))))))))))))
    work.sort(key=lambda item:(priority(item[0]),-item[2],-len(item[1]),item[0]))
    output=[]; lengths: dict[str,float]={}
    failed: list[str]=[]
    for net,points,_span in work:
        if net=="SD_3V3": root=min(points,key=lambda p:(p[1],p[0]))
        elif net in power_first: root=min(points,key=lambda p:(p[1],p[0]))
        elif net in sd_bus or net in nand_bus: root=min(points,key=lambda p:(p[1],p[0]))
        elif net.startswith("USB_D"): root=min(points,key=lambda p:(p[1],p[0]))
        else: root=min(points)
        tree={(root[0],root[1],0),(root[0],root[1],1)}
        remaining=set(points); remaining.remove(root)
        total=0.0; branch=0
        routed=True
        while remaining:
            point=min(remaining,key=lambda p:min(abs(p[0]-t[0])+abs(p[1]-t[1]) for t in tree))
            targets={(point[0],point[1],0),(point[0],point[1],1)}
            path=route_one(tree,targets,net)
            if path is None:
                failed.append(f"{net}@{point}")
                routed=False
                break
            branch+=1
            # Emit the uncompressed grid walk. KiCad coalesces visually; keeping
            # each step makes obstacle accounting and length audit deterministic.
            for idx in range(len(path)-1):
                a=path[idx]; b=path[idx+1]
                if a[2]!=b[2]:
                    x=a[0]*grid; y=a[1]*grid
                    output.append(_via(x,y,net,net_ids,f"route-via-{net}-{branch}-{idx}"))
                    for layer in range(2): mark_routed(layer,a[0],a[1],net,2.0)
                else:
                    x1=a[0]*grid; y1=a[1]*grid; x2=b[0]*grid; y2=b[1]*grid
                    width=.25 if net in {"VBUS","VBAT","VSYS","CORE_0V93","DRAM_1V5","1V8","RTC_3V3","LCD_3V3","SD_3V3","LEDA","LEDK"} else .12
                    output.append(f'\t(segment (start {x1:.4f} {y1:.4f}) (end {x2:.4f} {y2:.4f}) (width {width:.3f}) (layer {q(layers[a[2]])}) (net {net_ids[net]}) (uuid {q(uid(f"route-seg-{net}-{branch}-{idx}"))}))')
                    total+=grid
                tree.add(a); tree.add(b)
            for x,y,layer in path: mark_routed(layer,x,y,net,1.1)
            # A through via is present at every escape terminal.
            tree.add((point[0],point[1],0)); tree.add((point[0],point[1],1))
            remaining.remove(point)
        if routed:
            lengths[net]=total
    OUT.mkdir(parents=True,exist_ok=True)
    with (OUT/"unrouted_nets.txt").open("w") as f:
        f.write("# Non-display nets the maze did not finish. Display nets are frozen and omitted.\n")
        for item in failed:
            f.write(item+"\n")
        if not failed:
            f.write("# none\n")
    return output,lengths


def copper_zones(net_ids: dict[str,int]) -> list[str]:
    def zone(net: str, layer: str, priority: int, points: list[tuple[float,float]], suffix: str) -> str:
        pts=" ".join(f"(xy {x:g} {y:g})" for x,y in points)
        return f'''\t(zone (net {net_ids[net]}) (net_name {q(net)}) (layer {q(layer)}) (uuid {q(uid("zone-"+net+"-"+layer))}) (hatch edge 0.5) (priority {priority})
\t\t(connect_pads (clearance .10)) (min_thickness .12) (fill yes (thermal_gap .25) (thermal_bridge_width .25))
\t\t(polygon (pts {pts}))
\t)'''
    full=[(.5,.5),(57.5,.5),(57.5,109.5),(.5,109.5)]
    # A single concave polygon forms the SoC lobe, PMIC lobe and connecting neck.
    core=[(2,82),(15,82),(15,64),(21,64),(21,48),(38,48),(38,64),(25,64),(25,100),(2,100)]
    v1v8=[(12,46),(46,46),(46,76),(24,76),(24,100),(12,100)]
    dram=[(2,86),(10,86),(10,100),(2,100)]
    rtc=[(4,14),(36,14),(36,32),(6,32),(6,92),(20,92),(20,78),(4,78)]
    lcd3=[(14,36),(34,36),(34,44),(14,44)]
    return [
        zone("GND","In1.Cu",1,full,"plane"),
        zone("3V3","In2.Cu",1,full,"plane"),
        zone("CORE_0V93","In2.Cu",2,core,"pour"),
        zone("1V8","B.Cu",3,v1v8,"pour"),
        zone("DRAM_1V5","B.Cu",4,dram,"pour"),
        zone("RTC_3V3","B.Cu",3,rtc,"pour"),
        zone("LCD_3V3","B.Cu",4,lcd3,"pour"),
    ]


def manual_front_routes(net_ids: dict[str,int]) -> list[str]:
    """Top-layer routes that must pass outside the buried high-speed bundle."""
    paths={
        "LCD_RST":[(23.2,50.4),(11.0,50.4),(11.0,34.0),(33.8,34.0),(33.8,39.8)],
        "LCD_EN":[(23.2,51.6),(24.5,51.6),(24.5,48.8),(18.2,48.8),(18.2,41.4)],
        "LEDA":[(34.8,39.8),(34.8,36.0),(49.0,36.0)],
        "LEDK":[(34.2,39.8),(34.2,42.6),(44.0,42.6)],
        "LCD_3V3":[(16.0,40.0),(20.0,40.0),(27.0,40.0),(27.0,39.0)],
    }
    out=[]
    for net,points in paths.items():
        for idx,(a,b) in enumerate(zip(points,points[1:])):
            out.append(f'\t(segment (start {a[0]:.4f} {a[1]:.4f}) (end {b[0]:.4f} {b[1]:.4f}) (width .12) (layer "F.Cu") (net {net_ids[net]}) (uuid {q(uid(f"manual-{net}-{idx}"))}))')
    return out


def board(devs: list[Device]) -> str:
    nets=sorted({net for d in devs for _n,net in d.pins.values() if net})
    net_ids={n:i+1 for i,n in enumerate(nets)}
    out=['(kicad_pcb','\t(version 20241229)','\t(generator "pcbnew")','\t(generator_version "9.0")','\t(general (thickness 1.0) (legacy_teardrops no))','\t(paper "A4")','\t(layers (0 "F.Cu" signal) (2 "In1.Cu" power "GND plane") (4 "In2.Cu" power "3V3 plane") (6 "B.Cu" signal) (9 "F.Adhes" user "F.Adhesive") (11 "B.Adhes" user "B.Adhesive") (13 "F.Paste" user) (15 "B.Paste" user) (5 "F.SilkS" user "F.Silkscreen") (7 "B.SilkS" user "B.Silkscreen") (1 "F.Mask" user) (3 "B.Mask" user) (17 "Dwgs.User" user "User.Drawings") (19 "Cmts.User" user "User.Comments") (25 "Edge.Cuts" user) (27 "Margin" user) (31 "F.CrtYd" user) (29 "B.CrtYd" user) (35 "F.Fab" user) (33 "B.Fab" user))','\t(setup (pad_to_mask_clearance 0) (allow_soldermask_bridges_in_footprints no) (tenting front back))','\t(net 0 "")']
    out += [f'\t(net {i} {q(n)})' for n,i in net_ids.items()]
    out += [footprint_instance(d,net_ids) for d in devs]
    routes, _fanout_report = deterministic_fanout_and_routes(devs, net_ids)
    therm=[]
    for name,cx,cy,span in (("u2",30.0,56.0,2.4),("u1",18.0,85.0,1.6)):
        n=0
        for dx in (-span/2,0,span/2):
            for dy in (-span/2,0,span/2):
                n+=1
                therm.append(_via(cx+dx,cy+dy,"GND",net_ids,f"thermal-{name}-{n}"))
    out += therm+routes+copper_zones(net_ids)
    out += ['\t(gr_rect (start 22 38) (end 38 53) (stroke (width .15) (type dash)) (fill none) (layer "Dwgs.User") (uuid "'+uid('display-keepout')+'"))']
    out += ['\t(gr_text "DISPLAY ISLAND FROZEN\\n(MIPI / FPC / backlight)" (at 30 45) (layer "Dwgs.User") (uuid "'+uid('display-keepout-text')+'") (effects (font (size 0.8 0.8) (thickness .12))))']
    # Board-only mounting holes.
    for i,(x,y) in enumerate([(3,3),(55,3),(3,107),(55,107)],1):
        out += [f'\t(footprint "MountingHole_{i}" (layer "F.Cu") (at {x} {y}) (uuid {q(uid(f"mh{i}"))}) (property "Reference" {q(f"H{i}")} (at 0 -3 0) (layer "F.SilkS") (effects (font (size .8 .8)))) (property "Value" "M2" (at 0 3 0) (layer "F.Fab") (effects (font (size .8 .8)))) (attr exclude_from_pos_files exclude_from_bom) (fp_circle (center 0 0) (end 2 0) (stroke (width .2) (type default)) (fill none) (layer "F.SilkS")) (pad "" np_thru_hole circle (at 0 0) (size 2.4 2.4) (drill 2.4) (layers "*.Cu" "*.Mask")))']
    out += [
        '\t(gr_rect (start 0 0) (end 58 110) (stroke (width .1) (type default)) (fill none) (layer "Edge.Cuts") (uuid "'+uid('edge')+'"))',
        '\t(gr_rect (start 4 15) (end 54 95) (stroke (width .15) (type dash)) (fill none) (layer "B.SilkS") (uuid "'+uid('battery-keepout')+'"))',
        '\t(gr_text "BATTERY KEEPOUT 50x80x6mm" (at 29 55 90) (layer "B.SilkS") (uuid "'+uid('battery-text')+'") (effects (font (size 1 1) (thickness .15))))',
        '\t(gr_text "Portable Display V1.0-EVT1\\nNOT PHYSICALLY VALIDATED" (at 29 103) (layer "B.SilkS") (uuid "'+uid('board-title')+'") (effects (font (size 1 1) (thickness .15)) (justify mirror)))',
        '\t(embedded_fonts no)',')']
    return "\n".join(out)+"\n"


def write_bom(devs: list[Device]) -> None:
    OUT.mkdir(parents=True,exist_ok=True)
    with (OUT/"portable_display_evt1_bom.csv").open("w",newline="") as f:
        w=csv.writer(f); w.writerow(["Comment","Designator","Footprint","LCSC Part #","Manufacturer Part","DNP","Notes"])
        grouped: dict[tuple,list[str]]={}
        exemplar: dict[tuple,Device]={}
        for d in devs:
            key=(d.value,d.footprint,d.lcsc,d.mpn,d.dnp,d.note); grouped.setdefault(key,[]).append(d.ref); exemplar[key]=d
        for key,refs in sorted(grouped.items(),key=lambda kv:kv[1][0]):
            e=exemplar[key]; w.writerow([e.value,",".join(refs),e.footprint,e.lcsc,e.mpn,"Yes" if e.dnp else "No",e.note])
    with (OUT/"portable_display_evt1_cpl.csv").open("w",newline="") as f:
        w=csv.writer(f); w.writerow(["Designator","Mid X","Mid Y","Layer","Rotation"])
        for d in devs:
            if not d.dnp: w.writerow([d.ref,f"{d.x:.3f}mm",f"{d.y:.3f}mm","Top",f"{d.rotation:.1f}"])
    with (OUT/"net_pin_report.csv").open("w",newline="") as f:
        w=csv.writer(f); w.writerow(["Reference","Pin","Pin Name","Net"])
        for d in devs:
            for p,(name,net) in d.pins.items(): w.writerow([d.ref,p,name,net or "NC"])


def write_docs() -> None:
    docs=ROOT/"docs"; docs.mkdir(exist_ok=True)
    (docs/"HARDWARE.md").write_text("""# Portable Display V1.0-EVT1 hardware notes

This is a reference-derived engineering validation design. The display island (MIPI DSI, FPC, backlight) is frozen pending an OLED panel lock; those nets are intentionally unrouted. Non-display power, USB, storage, keys and wake path are the active work. It has not been physically built or electrically validated.

## Architecture

- V851s boots Tina Linux on the Cortex-A7 and loads the E907 RTOS image. The E907 manages connected standby; the A7 resumes for display updates and H.264 playback.
- AXP2101 provides USB/battery power path, charging, rail sequencing and fuel-gauge data. The intended defaults are DCDC1=3.3 V, DCDC3=0.93 V, DCDC4=1.5 V and ALDO1=1.8 V. Confirm the ordered AXP2101 OTP/default configuration with the supplier before assembly.
- RV-3028-C7 and LIS2DW12 remain on `RTC_3V3`. Their active-low interrupts create an approximately 80 ms PWRON pulse through SN74LVC1G123 so a latched alarm cannot look like a long power-key press.

## Locked pin allocation

| Function | V851s pins |
|---|---|
| MIPI DSI | PD1 D0N, PD2 D0P, PD3 D1N, PD4 D1P, PD5 CKN, PD6 CKP |
| Display control | PD19 RESET, PD20 PWM, PD21 power enable |
| MicroSD | PF0-PF5 data/clock/command, PF6 detect, PH12 power control |
| SPI NAND | PC0-PC5 |
| Sensors | PE4 TWI0 SCL, PE5 TWI0 SDA, PE6 accelerometer IRQ, PE7 RTC IRQ |
| PMIC | PH13 SCL, PH14 SDA, PE2 IRQ |
| Debug | PH9/PH10 A7 UART0; PE0/PE1 E907 UART3 |
| Buttons | GPADC0 ladder; power key to AXP2101 PWRON |

## Display connector

`TFT-H035B22WVIST8N20_V3-0`, 20-pin 0.5 mm bottom-contact FPC:

| Pin | Signal | Pin | Signal |
|---:|---|---:|---|
| 1-5 | NC (touch option) | 6 | LCD_3V3 / VCI |
| 7 | LCD_3V3 / IOVCC | 8 | GND |
| 9 | DSI_D1P | 10 | DSI_D1N |
| 11 | GND | 12 | DSI_CKP |
| 13 | DSI_CKN | 14 | GND |
| 15 | DSI_D0P | 16 | DSI_D0N |
| 17 | GND | 18 | LCD_RST |
| 19 | LEDK | 20 | LEDA |

Timing: 480x800, HPW 10, HBP 48, HFP 48, VPW 10, VBP 20, VFP 20, nominal pixel clock 30 MHz. Copy the complete ST7701S initialization and sleep sequences from the purchased panel revision's datasheet into firmware; do not assume another ST7701S panel uses the same sequence.

## Mechanical and fabrication

- PCB: 58x110 mm, 1.0 mm, four layers. L1 components/signals, L2 solid ground, L3 power/slow signals, L4 signals.
- Nominal enclosure allowance: 62x114x15 mm. Rear battery envelope: maximum 50x80x6 mm.
- USB and MIPI are specified as 90-ohm differential networks. Recalculate physical trace geometry using the exact JLCPCB stackup selected at order time; do not substitute the nominal drawing values without an impedance coupon/order review.
- Through vias for QFN fanout are 0.40 mm / 0.20 mm drill (order JLCPCB with 0.20 mm via hole). The SoC-to-FPC rectangle is a drawing-layer keepout for a later OLED MIPI bundle.
- Display nets (DSI_*, LCD_*, LEDA/LEDK, BL_SW) are frozen. Do not treat unconnected display items as a reason to delay non-display bring-up.
- Screen and battery samples must be measured before mechanical freeze.
- Board origin is the bottom-left corner of Edge.Cuts (0, 0) in millimetres. CPL Mid X/Y uses that origin on the top side.

## Important limitations

- No firmware, enclosure, radio, audio, touch or always-on display is included.
- A generic AXP2101 may not contain the V851s rail defaults. Supplier confirmation is a fabrication gate.
- Stock levels and CPL rotations must be rechecked in the JLCPCB ordering preview.
- Do not order a display-capable PCBA until an OLED (or the current IPS) is locked and those nets are routed. A power/USB/storage spin is only useful if you accept no panel.
""")
    (docs/"BRINGUP.md").write_text("""# EVT1 bring-up checklist

1. Inspect orientation of U1/U2/U3/U4/U5/U6/U7, J1/J4/J5 and all diodes. Verify the LCD FPC contact side against the physical sample.
2. With no SoC, display or storage fitted, use a current-limited supply and verify VBUS, VBAT/VSYS and the AXP2101 power-key behavior.
3. Fit the PMIC passives and verify 3.3 V, 1.8 V, 1.5 V and 0.93 V in sequence. Stop immediately if any rail is outside +/-3% or rises in the wrong order.
4. Fit V851s and the 24 MHz crystal. Confirm UART0 boot output and USB FEL enumeration before fitting SPI NAND.
5. Program and read back W25N01GV; then verify MicroSD at conservative speed before enabling high-speed mode.
6. Power the LCD logic with backlight disabled. Verify DSI lane polarity, RESET and the panel initialization sequence. Increase backlight PWM gradually while measuring LED current; full-scale target is approximately 80 mA.
7. Verify LIS2DW12 and RV-3028-C7 over I2C, then test connected-standby and cold-wake pulses separately.
8. Measure: PMIC-off current (<150 uA target), E907 standby (<8 mA target), active display current, USB charging current and component temperature after 30 minutes of video.
9. Treat any bodge, supplier substitution or failed target as a V1.1 change. Do not mark this revision production-ready without a reviewed test log.
""")


def main() -> None:
    devs=devices()
    root,sheets=root_schematic()
    (ROOT/"portable_display_epass.kicad_sch").write_text(root)
    mapping={"power":"01_power.kicad_sch","soc":"02_soc_v851s.kicad_sch","sensors":"03_sensors.kicad_sch","interfaces":"04_interfaces.kicad_sch"}
    for name,file in mapping.items():
        (ROOT/file).write_text(schematic_for_sheet(name,devs,uid("root-schematic"),sheets[name]))
    write_local_footprints(devs)
    (ROOT/"portable_display_epass.kicad_pcb").write_text(board(devs))
    write_bom(devs)
    write_docs()
    print(f"Generated {len(devs)} assembled devices")


if __name__=="__main__":
    main()
